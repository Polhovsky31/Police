
import UIKit

class AuthMainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
