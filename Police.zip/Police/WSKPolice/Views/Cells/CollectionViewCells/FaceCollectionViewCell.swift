
import UIKit

class FaceCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var topImage: UIImageView?
    @IBOutlet weak var middleImage: UIImageView?
    @IBOutlet weak var bottomImage: UIImageView?

}
