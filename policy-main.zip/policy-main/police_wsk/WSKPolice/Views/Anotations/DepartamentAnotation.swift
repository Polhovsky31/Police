//
//  DepartamentAnotation.swift
//  WSKPolice
//
//  Created by Преподаватель on 11.10.2021.
//

import Foundation
import MapKit

class DepartamentAnotation: MKPointAnnotation{
    
    var pinCustomImageName:String!

}
