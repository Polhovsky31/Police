//
//  PhotoRobotsCollectionViewCell.swift
//  WSKPolice
//
//  Created by KS54 on 21.09.2021.
//

import UIKit

class PhotoRobotsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageImageView: UIImageView!
}
