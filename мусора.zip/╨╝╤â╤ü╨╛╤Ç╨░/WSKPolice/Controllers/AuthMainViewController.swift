//
//  AuthMainViewController.swift
//  WSKPolice
//
//  Created by Преподаватель on 08.10.2021.
//

import UIKit

class AuthMainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
