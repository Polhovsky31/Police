//
//  FaceCollectionViewCell.swift
//  WSKPolice
//
//  Created by Преподаватель on 07.10.2021.
//

import UIKit

class FaceCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var topImage: UIImageView?
    @IBOutlet weak var middleImage: UIImageView?
    @IBOutlet weak var bottomImage: UIImageView?

}
