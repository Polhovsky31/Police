//
//  PaintCollectionViewCell.swift
//  WSKPolice
//
//  Created by Преподаватель on 07.10.2021.
//

import UIKit

class PaintCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var button: UIButton!
    
}
